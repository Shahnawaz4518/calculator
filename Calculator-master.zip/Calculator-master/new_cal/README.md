
# Calculator!

## About Project

We are creating this Calculator so that, other developers can get the benefits of it.

Open index.html of new_cal folder.
NAME - SWASTIKA SARANGI
EMAIL - sarangi.swastika5@gmail.com
